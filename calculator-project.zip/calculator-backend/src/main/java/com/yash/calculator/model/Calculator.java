package com.yash.calculator.model;

public class Calculator {

	private String equation;

	public String getequation() {
		return equation;
	}

	public void setequation(String equation) {
		this.equation= equation;
	}

	public Calculator(String equation) {
		super();
		this.equation= equation;
	}

	public Calculator() {
		super();
	}
}
